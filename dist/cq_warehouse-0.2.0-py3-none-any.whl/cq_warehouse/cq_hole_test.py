from typing import Optional
import importlib.resources as pkg_resources
import csv
import cadquery as cq
import cq_warehouse

# from cq_warehouse.fastener import Screw

MM = 1
IN = 25.4 * MM

lettered_drill_sizes = {
    "A": 0.234 * IN,
    "B": 0.238 * IN,
    "C": 0.242 * IN,
    "D": 0.246 * IN,
    "E": 0.250 * IN,
    "F": 0.257 * IN,
    "G": 0.261 * IN,
    "H": 0.266 * IN,
    "I": 0.272 * IN,
    "J": 0.277 * IN,
    "K": 0.281 * IN,
    "L": 0.290 * IN,
    "M": 0.295 * IN,
    "N": 0.302 * IN,
    "O": 0.316 * IN,
    "P": 0.323 * IN,
    "Q": 0.332 * IN,
    "R": 0.339 * IN,
    "S": 0.348 * IN,
    "T": 0.358 * IN,
    "U": 0.368 * IN,
    "V": 0.377 * IN,
    "W": 0.386 * IN,
    "X": 0.397 * IN,
    "Y": 0.404 * IN,
    "Z": 0.413 * IN,
}
numbered_drill_sizes = {
    "#1": 0.228 * IN,
    "#2": 0.221 * IN,
    "#3": 0.213 * IN,
    "#4": 0.209 * IN,
    "#5": 0.205 * IN,
    "#6": 0.204 * IN,
    "#7": 0.201 * IN,
    "#8": 0.199 * IN,
    "#9": 0.196 * IN,
    "#10": 0.193 * IN,
    "#11": 0.191 * IN,
    "#12": 0.189 * IN,
    "#13": 0.185 * IN,
    "#14": 0.182 * IN,
    "#15": 0.18 * IN,
    "#16": 0.177 * IN,
    "#17": 0.173 * IN,
    "#18": 0.17 * IN,
    "#19": 0.166 * IN,
    "#20": 0.161 * IN,
    "#21": 0.159 * IN,
    "#22": 0.157 * IN,
    "#23": 0.154 * IN,
    "#24": 0.152 * IN,
    "#25": 0.15 * IN,
    "#26": 0.147 * IN,
    "#27": 0.144 * IN,
    "#28": 0.14 * IN,
    "#29": 0.136 * IN,
    "#30": 0.1285 * IN,
    "#31": 0.12 * IN,
    "#32": 0.116 * IN,
    "#33": 0.113 * IN,
    "#34": 0.111 * IN,
    "#35": 0.11 * IN,
    "#36": 0.1065 * IN,
    "#37": 0.104 * IN,
    "#38": 0.1015 * IN,
    "#39": 0.0995 * IN,
    "#40": 0.098 * IN,
    "#41": 0.096 * IN,
    "#42": 0.0935 * IN,
    "#43": 0.089 * IN,
    "#44": 0.086 * IN,
    "#45": 0.082 * IN,
    "#46": 0.081 * IN,
    "#47": 0.0785 * IN,
    "#48": 0.076 * IN,
    "#49": 0.073 * IN,
    "#50": 0.07 * IN,
    "#51": 0.067 * IN,
    "#52": 0.0635 * IN,
    "#53": 0.0595 * IN,
    "#54": 0.055 * IN,
    "#55": 0.052 * IN,
    "#56": 0.0465 * IN,
    "#57": 0.043 * IN,
    "#58": 0.042 * IN,
    "#59": 0.041 * IN,
    "#60": 0.04 * IN,
    "#61": 0.039 * IN,
    "#62": 0.038 * IN,
    "#63": 0.037 * IN,
    "#64": 0.036 * IN,
    "#65": 0.035 * IN,
    "#66": 0.033 * IN,
    "#67": 0.032 * IN,
    "#68": 0.031 * IN,
    "#69": 0.029 * IN,
    "#70": 0.028 * IN,
    "#71": 0.026 * IN,
    "#72": 0.025 * IN,
    "#73": 0.024 * IN,
    "#74": 0.0225 * IN,
    "#75": 0.021 * IN,
    "#76": 0.02 * IN,
    "#77": 0.018 * IN,
    "#78": 0.016 * IN,
    "#79": 0.0145 * IN,
    "#80": 0.0135 * IN,
}


def is_safe(value: str) -> bool:
    """ Evaluate if the given string is a fractional number save for eval() """
    return len(value) <= 10 and all(c in "0123456789./ " for c in set(value))


def imperial_str_to_float(measure: str) -> float:
    """ Convert an imperial measurement (possibly a fraction) to a float value """
    if not is_safe(measure):
        raise ValueError(f"{measure} is not a valid measurement")
    # pylint: disable=eval-used
    # Before eval() is called the string extracted from the csv file is verified as safe
    return eval(measure.strip().replace(" ", "+")) * IN


def read_fastener_parameters_from_csv(filename: str) -> dict:
    """ Parse a csv parameter file into a dictionary of strings """

    parameters = {}
    with pkg_resources.open_text(cq_warehouse, filename) as csvfile:
        reader = csv.DictReader(csvfile)
        fieldnames = reader.fieldnames
        for row in reader:
            key = row[fieldnames[0]]
            row.pop(fieldnames[0])
            parameters[key] = row

    return parameters


def lookup_drill_diameters(drill_hole_sizes: dict) -> dict:
    """ Return a dict of dict of drill size to drill diameter """
    drill_hole_diameters = {}
    for size, drill_data in drill_hole_sizes.items():
        hole_data = {}
        for fit, drill in drill_data.items():
            if drill in numbered_drill_sizes.keys():
                hole_data[fit] = numbered_drill_sizes[drill]
            elif drill in lettered_drill_sizes.keys():
                hole_data[fit] = lettered_drill_sizes[drill]
            else:
                hole_data[fit] = imperial_str_to_float(drill)
        drill_hole_diameters[size] = hole_data
    return drill_hole_diameters


# Soft for Aluminum, Brass, & Plastics
# Hard for Steel, Stainless, & Iron

metric_clearance_hole_data = read_fastener_parameters_from_csv(
    "metric_clearance_hole_sizes.csv"
)
metric_tap_hole_data = read_fastener_parameters_from_csv("metric_tap_hole_sizes.csv")

imperial_clearance_hole_drill_sizes = read_fastener_parameters_from_csv(
    "imperial_clearance_hole_sizes.csv"
)
imperial_tap_hole_drill_sizes = read_fastener_parameters_from_csv(
    "imperial_tap_hole_sizes.csv"
)
imperial_clearance_hole_data = lookup_drill_diameters(
    imperial_clearance_hole_drill_sizes
)
imperial_tap_hole_data = lookup_drill_diameters(imperial_tap_hole_drill_sizes)

print(metric_clearance_hole_data)
print(metric_tap_hole_data)
print(imperial_clearance_hole_data)
print(imperial_tap_hole_data)

# def _clearanceHole(
#     self: T,
#     screw: Screw,
#     counterSunk: Optional[bool] = True,
#     clean: Optional[bool] = True,
# ) -> T:
#     """
#     Makes a countersunk hole for each item on the stack.

#     :param diameter: the diameter of the hole
#     :type diameter: float > 0
#     :param cskDiameter: the diameter of the countersink
#     :type cskDiameter: float > 0 and > diameter
#     :param cskAngle: angle of the countersink, in degrees ( 82 is common )
#     :type cskAngle: float > 0
#     :param depth: the depth of the hole
#     :type depth: float > 0 or None to drill thru the entire part.
#     :param boolean clean: call :py:meth:`clean` afterwards to have a clean shape

#     The surface of the hole is at the current workplane.

#     One hole is created for each item on the stack.  A very common use case is to use a
#     construction rectangle to define the centers of a set of holes, like so::

#             s = Workplane(Plane.XY()).box(2,4,0.5).faces(">Z").workplane()\
#                 .rect(1.5,3.5,forConstruction=True)\
#                 .vertices().cskHole(0.125, 0.25,82,depth=None)

#     This sample creates a plate with a set of holes at the corners.

#     **Plugin Note**: this is one example of the power of plugins. CounterSunk holes are quite
#     time consuming to create, but are quite easily defined by users.

#     see :py:meth:`cboreHole` to make counterbores instead of countersinks
#     """

#     # if depth is None:
#     #     depth = self.largestDimension()

#     boreDir = cq.Vector(0, 0, -1)
#     center = cq.Vector()

#     shank_hole = screw.shank.shell(clearance)
#     # first make the hole
#     hole = cq.Solid.makeCylinder(diameter / 2.0, depth, center, boreDir)  # local coords!
#     r = cskDiameter / 2.0
#     h = r / math.tan(math.radians(cskAngle / 2.0))
#     csk = Solid.makeCone(r, 0.0, h, center, boreDir)
#     res = hole.fuse(csk)

#     return self.cutEach(lambda loc: res.moved(loc), True, clean)


# cq.cq.clearanceHole = _clearanceHole
