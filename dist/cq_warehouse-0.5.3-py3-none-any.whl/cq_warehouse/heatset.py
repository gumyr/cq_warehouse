from typing import Literal
import math
import cadquery as cq
from cadquery import Vector, Shell, Workplane, Face, Edge, Wire, Solid
from cq_warehouse.thread import IsoThread
import timeit
import cq_warehouse.extensions

# from cq_warehouse.extensions import makeNonPlanarFace
from cq_warehouse.fastener import (
    read_fastener_parameters_from_csv,
    read_drill_sizes,
    Nut,
)
import os

MM = 1


class InsertNut:
    smseace_data = {
        "M2x0.4-4": (3.5, 0.8, 22),
        "M2x0.4-6": (3.5, 2.4, 22),
        "M2x0.4-8": (3.5, 2.9, 22),
        "M2x0.4-10": (3.5, 2.9, 22),
        "M3x0.5-4": (5.0, 0.5, 22),
        "M3x0.5-6": (5.0, 1.2, 22),
        "M3x0.5-8": (5.0, 1.2, 22),
        "M3x0.5-10": (5.0, 1.5, 22),
        "M4x0.7-4": (6.0, 1.2, 22),
        "M4x0.7-6": (6.0, 1, 22),
        "M4x0.7-8": (6.0, 2, 22),
        "M4x0.7-10": (6.0, 2, 22),
        "M5x0.8-6": (7.0, 1.4, 22),
        "M5x0.8-8": (7.0, 1.8, 22),
        "M5x0.8-10": (7.0, 1.8, 22),
    }

    def __init__(self, size: str):
        self.size = size.strip()
        if self.size not in InsertNut.smseace_data.keys():
            raise ValueError(
                f"Invalid size - must be one of {list(InsertNut.smseace_data.keys())}"
            )
        self.thread_diameter = int(self.size[1])
        self.pitch = float(self.size.split("-")[0].split("x")[1])
        self.length = int(self.size.split("-")[1])
        (
            self.outside_diameter,
            self.gap_size,
            self.tip_count,
        ) = InsertNut.smseace_data[self.size]
        self.thread = IsoThread(
            major_diameter=self.thread_diameter,
            pitch=self.pitch,
            length=self.length,
            external=False,
        )
        self.gap_radius = (self.thread_diameter + self.outside_diameter) / 4

        nut = self.nut_profile().toPending().revolve()

        # Modify the head to conform to the shape of head_plan (e.g. hex)
        # Note that some nuts (e.g. domed nuts) extend beyond the threaded section
        nut_blank = (
            Workplane("XY")
            .add(self.nut_plan().wires().val())
            .toPending()
            .extrude(self.length)
            .faces("<Z")
            .workplane()
            .hole(self.thread_diameter, self.length)
        )
        nut = nut.intersect(nut_blank)
        self.cq_object = nut

    def nut_profile(self):
        """Create 2D profile of heat sets with symmetrical ends"""

        profile = (
            Workplane("XZ")
            .moveTo(self.thread.root_radius, 0)
            .hLineTo(self.outside_diameter / 2)
            .vLine((self.length - self.gap_size) / 2)
            .hLineTo(self.gap_radius)
            .vLine(self.gap_size)
            .hLineTo(self.outside_diameter / 2)
            .vLineTo(self.length)
            .hLineTo(self.thread.root_radius, 0)
            .close()
        )
        return profile

    def nut_plan(self):
        knurl_points = [
            (
                Vector(self.gap_radius, 0, 0).rotateZ(i * 360 / self.tip_count),
                Vector(self.outside_diameter / 2, 0, 0).rotateZ(
                    (i + 0.5) * 360 / self.tip_count
                ),
            )
            for i in range(self.tip_count)
        ]
        # Flatten the list of tuples of Vectors to a list of Vectors
        knurl_points = list(sum(knurl_points, ()))
        return Workplane("XY").polyline(knurl_points).close()


# nut = InsertNut("M5x0.8-10")
# print(nut.__dict__)
# plan = nut.nut_plan()


class HeatSetNut(Nut):
    """Heat Set Nut

    Args:
        size (str): nut size, e.g. M5-0.8-Standard
        fastener_type (str): standard or manufacturer that defines the nut ["McMaster-Carr"]
        hand (Literal["right", "left"], optional): direction of thread. Defaults to "right".
        simple (bool): omit the thread from the nut. Defaults to True.

    Attributes:
        fill_factor (float): Fraction of insert hole filled with heatset nut
    """

    fastener_data = read_fastener_parameters_from_csv("heatset_nut_parameters.csv")

    @staticmethod
    def knurled_cylinder_faces(
        diameter: float,
        bottom_hole_radius: float,
        top_hole_radius: float,
        height: float,
        knurl_depth: float,
        pitch: float,
        tip_count: int,
        hand: Literal["right", "left"] = "right",
    ) -> list[Face]:
        """Faces of Knurled Cylinder

        Generate a list of Faces on a knurled cylinder with a central hole. These faces are
        used to build a knurled HeatSet insert with maximal performance.

        Args:
            diameter (float): outside diameter of knurled cylinder
            bottom_hole_radius (float): size of bottom hole
            top_hole_radius (float): size of top hole
            height (float): end-to-end height
            knurl_depth (float): size of the knurling
            pitch (float): knurling helical pitch
            tip_count (int): number of knurled tips
            hand (Literal["right", "left"], optional): direction of knurling. Defaults to "right".

        Returns:
            list[Face]: Faces of the knurled cylinder except for central hole
        """

        # Start by creating helical edges for the inside and outside of the knurling
        lefthand = hand == "left"
        inside_edges = [
            Wire.makeHelix(pitch, height, diameter / 2 - knurl_depth, lefthand=lefthand)
            .Edges()[0]
            .rotate(Vector(0, 0, 0), Vector(0, 0, 1), i * 360 / tip_count)
            for i in range(tip_count)
        ]
        outside_edges = [
            Wire.makeHelix(pitch, height, diameter / 2, lefthand=lefthand)
            .Edges()[0]
            .rotate(Vector(0, 0, 0), Vector(0, 0, 1), (i + 0.5) * 360 / tip_count)
            for i in range(tip_count)
        ]
        # Connect the bottoms of the helical edges into a star shaped bottom face
        bottom_edges = [
            (
                Edge.makeLine(
                    inside_edges[i].positionAt(0), outside_edges[i].positionAt(0)
                ),
                Edge.makeLine(
                    outside_edges[i].positionAt(0),
                    inside_edges[(i + 1) % tip_count].positionAt(0),
                ),
            )
            for i in range(tip_count)
        ]
        # Flatten the list of tuples to a list
        bottom_edges = list(sum(bottom_edges, ()))
        # Close the edges by connecting the last to first
        bottom_edges.append(
            Edge.makeLine(
                outside_edges[-1].positionAt(0),
                inside_edges[0].positionAt(0),
            )
        )
        top_edges = [
            (
                Edge.makeLine(
                    inside_edges[i].positionAt(1), outside_edges[i].positionAt(1)
                ),
                Edge.makeLine(
                    outside_edges[i].positionAt(1),
                    inside_edges[(i + 1) % tip_count].positionAt(1),
                ),
            )
            for i in range(tip_count)
        ]
        top_edges = list(sum(top_edges, ()))
        top_edges.append(
            Edge.makeLine(
                outside_edges[-1].positionAt(1),
                inside_edges[0].positionAt(1),
            )
        )

        # Build the faces from the edges
        outside_faces = [
            (
                Face.makeNSidedSurface(
                    [
                        inside_edges[i],
                        outside_edges[i],
                        bottom_edges[2 * i],
                        top_edges[2 * i],
                    ],
                    [],
                ),
                Face.makeNSidedSurface(
                    [
                        outside_edges[i],
                        inside_edges[(i + 1) % tip_count],
                        bottom_edges[2 * i + 1],
                        top_edges[2 * i + 1],
                    ],
                    [],
                ),
            )
            for i in range(tip_count)
        ]
        outside_faces = list(sum(outside_faces, ()))

        # Create the top and bottom faces with holes in them
        bottom_face = Face.makeFromWires(
            Wire.assembleEdges(bottom_edges),
            [
                Wire.makeCircle(
                    bottom_hole_radius, center=Vector(0, 0, 0), normal=Vector(0, 0, 1)
                )
            ],
        )
        top_face = Face.makeFromWires(
            Wire.assembleEdges(top_edges),
            [
                Wire.makeCircle(
                    top_hole_radius,
                    center=Vector(0, 0, height),
                    normal=Vector(0, 0, 1),
                )
            ],
        )

        return [bottom_face, top_face] + outside_faces

    @property
    def fill_factor(self) -> float:
        """Relative size of nut vs hole

        Returns:
            float: Fraction of insert hole filled with heatset nut
        """
        drill_sizes = read_drill_sizes()
        hole_radius = drill_sizes[self.nut_data["drill"].strip()] / 2
        heatset_volume = (
            self.cq_object.Volume()
            + self.nut_data["m"] * math.pi * (self.thread_diameter / 2) ** 2
        )
        hole_volume = self.nut_data["m"] * math.pi * hole_radius ** 2
        return heatset_volume / hole_volume

    def make_nut(self) -> cq.Workplane:
        """Build heatset nut object

        Create the heatset nut with a flanged bottom and two knurled sections
        with opposite twist direction which locks into the plastic when heated
        and inserted into an appropriate hole.

        To maximize performance, the nut is created by building assembling Faces
        into a Shell which is converted to a Solid. No extrusions or boolean
        operations are used until the thread is added to the nut.

        Returns:
            cq.Workplane: the heatset nut
        """
        nut_base = (
            Workplane("XZ")
            .hLineTo(self.nut_data["dc"] / 2)
            .vLineTo(0.11 * self.nut_data["m"])
            .hLineTo(0.425 * self.nut_data["dc"])
            .vLineTo(0.24 * self.nut_data["m"])
            .hLineTo(0)
            .close()
            .revolve()
        )
        base_bottom_face = (
            nut_base.faces("%Plane and <Z")
            .faces()
            .val()
            .makeHoles(
                [
                    Wire.makeCircle(
                        self.thread_diameter / 2,
                        center=Vector(0, 0, 0),
                        normal=Vector(0, 0, 1),
                    )
                ]
            )
        )
        base_outside_faces = nut_base.faces("not <Z").faces("not >Z").vals()

        # Create the lower knurled section Faces
        lower_knurl_faces = HeatSetNut.knurled_cylinder_faces(
            self.nut_data["s"],
            0.425 * self.nut_data["dc"],
            0.425 * self.nut_data["dc"],
            height=0.33 * self.nut_data["m"],
            knurl_depth=0.1 * self.nut_data["s"],
            pitch=3 * self.nut_data["m"],
            tip_count=self.nut_data["knurls"],
            hand="right",
        )
        lower_knurl_faces = [
            f.translate(Vector(0, 0, 0.24 * self.nut_data["m"]))
            for f in lower_knurl_faces
        ]

        # Create the Face in the gap between the knurled sections
        nut_middle_face = (
            Workplane("XY", origin=(0, 0, 0.57 * self.nut_data["m"]))
            .cylinder(
                0.1 * self.nut_data["m"],
                0.425 * self.nut_data["dc"],
                centered=(True, True, False),
            )
            .faces("not %Plane")
            .val()
        )

        # Create the Faces in the upper knurled section
        upper_knurl_faces = HeatSetNut.knurled_cylinder_faces(
            self.nut_data["s"],
            0.425 * self.nut_data["dc"],
            self.thread_diameter / 2,
            height=0.33 * self.nut_data["m"],
            knurl_depth=0.1 * self.nut_data["s"],
            pitch=3 * self.nut_data["m"],
            tip_count=20,
            hand="left",
        )
        upper_knurl_faces = [
            f.translate(Vector(0, 0, 0.67 * self.nut_data["m"]))
            for f in upper_knurl_faces
        ]

        # Create the Face for the inside of the nut
        thread_hole_face = (
            Workplane("XY")
            .cylinder(
                self.nut_data["m"],
                self.thread_diameter / 2,
                centered=(True, True, False),
            )
            .faces("not %Plane")
            .val()
        )

        # Build a Shell of the nut from all of the Faces
        nut_shell = Shell.makeShell(
            [base_bottom_face, nut_middle_face, thread_hole_face]
            + base_outside_faces
            + lower_knurl_faces
            + upper_knurl_faces
        )

        # Finally create the Solid from the Shell
        nut = Workplane(Solid.makeSolid(nut_shell))

        # Add the thread to the nut body
        if not self.simple:
            # Create the thread
            thread = IsoThread(
                major_diameter=self.thread_diameter,
                pitch=self.thread_pitch,
                length=self.nut_data["m"],
                external=False,
                end_finishes=("fade", "fade"),
                hand=self.hand,
            )
            nut = nut.union(thread.cq_object)

        return nut

    def nut_profile(self):
        """Not used but required by the abstract base class"""
        pass

    def nut_plan(self):
        """Not used but required by the abstract base class"""
        pass

    def countersink_profile(
        self, manufacturingCompensation: float = 0.0
    ) -> cq.Workplane:
        """_summary_

        Create the profile for a cavity allowing the heatset nut to be countersunk into the plastic.

        Args:
            manufacturingCompensation (float, optional): used to compensate for over-extrusion
                of 3D printers. A value of 0.2mm will reduce the radius of an external thread
                by 0.2mm (and increase the radius of an internal thread) such that the resulting
                3D printed part matches the target dimensions. Defaults to 0.0.

        Returns:
            cq.Workplane: The countersink hole profile
        """
        drill_sizes = read_drill_sizes()
        hole_radius = (
            drill_sizes[self.nut_data["drill"].strip()] / 2 + manufacturingCompensation
        )
        # chamfer_size = self.nut_data["s"] / 2 - hole_radius
        return (
            cq.Workplane("XZ")
            .hLine(hole_radius)
            .vLine(self.nut_data["m"])
            # .vLine(self.nut_data["m"]-chamfer_size)
            # .lineTo(self.nut_data["s"] / 2, self.nut_data["m"])
            .hLineTo(0)
            .close()
        )


# print(os.path.dirname(cq.__file__))
start_time = timeit.default_timer()
# curve_face = Workplane("XY").cylinder(10, 10).faces("not %Plane").val()
# curve_edges = Workplane("XY").cylinder(10, 10).edges().vals()
# bottom_edge = Edge.makeCircle(10)
# top_edge = Edge.makeCircle(10, pnt=(0, 0, 10))
# edge0 = Edge.makeLine(bottom_edge.positionAt(0), top_edge.positionAt(0))
# edge1 = Edge.makeLine(top_edge.positionAt(1), bottom_edge.positionAt(0))
# # curve_face = makeNonPlanarFace([bottom_edge, top_edge, edge0])
# curve_face = Face.makeNSidedSurface(
#     curve_edges, points=[Vector(0, 10, 2).toPnt(), Vector(0, -10, 2).toPnt()]
# )
nut = HeatSetNut(size="M5-0.8-Standard", fastener_type="McMaster-Carr", simple=True)
# nuts = []
# for nut_size in HeatSetNut.mcmaster_carr_data.keys():
#     nuts.append(HeatSetNut(size=nut_size, simple=False).cq_object)
elapsed_time = timeit.default_timer() - start_time
print(f"Generated in {elapsed_time:.6f}s")
cp = nut.countersink_profile()
# knurl = knurled_cylinder(diameter=12, height=10, knurl_depth=1, pitch=60, tip_count=20)
print(
    nut.cq_object.Volume()
    + nut.nut_data["m"] * math.pi * (nut.thread_diameter / 2) ** 2
)
print(cp.revolve().val().Volume())
if "show_object" in locals():
    show_object(nut.cq_object, name="nut")
    show_object(cp, name="countersink profile")
    # show_object(bottom_edge, name="bottom_edge")
    # show_object(top_edge, name="top_edge")
    # show_object(curve_face, name="curve_face")
    # for i, e in enumerate(curve_edges):
    #     show_object(e, name="edge" + str(i))
    # show_object(plan, name="plan")
    # show_object(profile, name="profile")
    # show_object(nut_blank, name="nut_blank")
    # show_object(edge0, name="edge0")
    # show_object(edge1, name="edge1")
    # show_object(edge2, name="edge2")
    # show_object(face0, name="face0")
    # show_object(face1, name="face1")
    # show_object(face2, name="face2")
    # show_object(face3, name="face3")
    # show_object(face4, name="face4")
    # show_object(knurl, name="knurl")
